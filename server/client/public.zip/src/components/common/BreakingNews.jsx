import React from 'react'
import { Link } from 'react-router-dom';

const BreakingNews = () => {
    return (
        <div className="flex border-2 border-red border-r-0 bg-red items-center my-2 ">
            <div className="py-1 px-3 font-medium text-white text-nowrap lg:text-3xl md:text-sm md:px-3 sm:text-xs">
                Breaking News
            </div>
            <marquee className=" rounded-l-full bg-white w-full py-1.5 px-4 font-lg lg:text-sm sm:text-xs">
                <div className="flex gap-96">
                    <div>
                        <Link to="/" className="text-2xl font-medium">
                            रायबरेली और अमेठी को बपौती समझती है कांग्रेस', यूपी के डिप्टी
                            सीएम केशव प्रसाद मौर्य ने कसा तंज{" "}
                        </Link>
                    </div>
                    <div>
                        <Link to="/" className="text-2xl font-medium">
                            रायबरेली और अमेठी को बपौती समझती है कांग्रेस', यूपी के डिप्टी
                            सीएम केशव प्रसाद मौर्य ने कसा तंज{" "}
                        </Link>
                    </div>
                </div>
            </marquee>
        </div>
    )
}

export default BreakingNews;
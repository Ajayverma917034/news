import React from "react";
import NewsSection from "./common/news-section/news.section.component";
import Heading from "./common/Heading";
import SubNewsCard from "./common/news-section/SubNewsCard";
import adsimgright1 from "../assets/adsimgright1.png";
import adsimgright2 from "../assets/adsimgright2.png";
import NewsVideo from "./common/news-video/news.video.section.component";

const HomeRightBar = ({ data, title }) => {
  console.log(data);
  return (
    <>
      <div className="flex spacing mt-2 sm:mt-8 ">
        <div className="grid grid-cols-1 lg:grid-cols-6 mx-auto  gap-5 ">
          <div className="flex flex-col flex-wrap  md:col-span-4 overflow-hidden">
            <div >
              <NewsSection data={data} title={title} />
            </div>
            <div>
              <NewsVideo data={data} title='टॉप वीडियो' />
            </div>
          </div>
          <div className="flex flex-col md:gap-y-10 gap-y-2  md:col-span-2 mt-10">
            <div className="flex flex-wrap  gap-y-1 gap-x-4 md:flex md:w-full  justify-center lg:flex-col ">
              <div className="w-[330px] h-[260px] overflow-hidden">
                <img
                  className="w-full h-auto object-contain"
                  src={adsimgright1}
                />
              </div>
              <div className="w-[330px] h-[260px] overflow-hidden">
                <img
                  className="w-full h-auto object-contain"
                  src={adsimgright2}
                />
              </div>
            </div>
            <div className=" flex-col gap-y-3 py-3 px-5 shadow-light-shadow rounded-md  hidden lg:flex ">
              <Heading title={"यह भी पढ़े"} />
              <div className="flex lg:flex-col gap-y-4 gap-5">
                <SubNewsCard />
                <SubNewsCard />
                <SubNewsCard />
                <SubNewsCard />
                <SubNewsCard />
                <SubNewsCard />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomeRightBar;

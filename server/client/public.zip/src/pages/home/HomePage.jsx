import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import NewsSection from "../../components/common/news-section/news.section.component";
import HomeRightBar from "../../components/home.component";
import httpClient from "../../api/httpClient";
import HomeRightBarOther from "../../components/home.component.other";

const HomePage = () => {
  const [homeNews, setHomeNews] = useState([[], [], [], []]);
  const [loading, setLoading] = useState(true);

  const data = ["बड़ी ख़बरें", "uttar pradesh", "crime", "education"];
  const fetchHomeNews = async () => {
    httpClient
      .post("/news/home", { data })
      .then(({ data }) => {
        setHomeNews(data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    fetchHomeNews();
  }, []);
  return (
    <>
      <div className="py-4">
        <div>
          <HomeRightBar data={homeNews[3]} title="बड़ी ख़बरें" />
          <HomeRightBarOther data={homeNews[3]} title="एजुकेशन" />
        </div>
      </div>
    </>
  );
};

export default HomePage;
